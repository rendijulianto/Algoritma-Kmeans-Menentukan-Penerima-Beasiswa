tinymce.init({
    selector: 'textarea#mymce'
});