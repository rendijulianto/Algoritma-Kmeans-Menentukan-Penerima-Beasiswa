<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="white-box">
            <h3 class="box-title">Mahasiswa</h3>
            <div class="widget-content searchable-container list">
                <div class="card card-body">
                  <div class="alert alert-danger">
                    <h4 class="alert-heading">Peringatan!</h4>
                    <p class="mb-0">
                      <strong>Perhatian!</strong> Pastikan data mahasiswa sudah diimport sebelum melakukan proses k-means.
                    </p>
                  </div>
                
                  <div class="table-responsive">
                    <table class="table search-table v-middle">
                      <thead class="header-item">
                    
                        <th class="font-weight-medium fs-4">Nama</th>
                        
                        <th class="font-weight-medium fs-4">C1</th>
                        <th class="font-weight-medium fs-4">C2</th>
                        <th class="font-weight-medium fs-4">C3</th>
                        <th class="font-weight-medium fs-4">C4</th>
                        <th class="font-weight-medium fs-4">Cluster</th>
                      </thead>
                      <tbody>
                       <?php $__empty_1 = true; $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <!-- row -->
                        <tr class="search-items">
                          
                          <td>
                            <div class="d-flex align-items-center">
                              <img
                                 src="<?php echo e(asset('assets/images/profile/user-1.jpg')); ?>"
                                 class="rounded  round-50"
                                 />
                              <div class="ms-3">
                                 <h6 class=" mb-0">
                                    <?php echo e($mhs->nama); ?>

                                 </h6>
                                 <span class="text-muted"
                                    ><?php echo e($mhs->jurusan); ?>

                                    </span
                                    >
                                 <br />
                              </div>
                           </div>
                          </td>
                           
                            <?php 
                        
                              $c1 = euclideanDistanceBeasiswa($centroid['centroid_1'], $mhs);
                              $c2 = euclideanDistanceBeasiswa($centroid['centroid_2'], $mhs);
                              $c3 = euclideanDistanceBeasiswa($centroid['centroid_3'], $mhs);
                              $c4 = euclideanDistanceBeasiswa($centroid['centroid_4'], $mhs);
                              $cluster = clusterBeasiswa($c1, $c2, $c3, $c4);
                              
                            ?>
                           <td>
                              <?php echo e($c1); ?>

                           </td>
                            <td>
                                <?php echo e($c2); ?>

                            </td>
                            <td>
                                <?php echo e($c3); ?>

                            </td>
                            <td>
                                <?php echo e($c4); ?>

                            </td>
                            <td>
                                <?php echo e($cluster); ?>

                            </td>
                          </tr>
                          <!-- /.row -->
                          <?php 
                            
                            $hasil_iterasi = DB::table('hasil_iterasi_beasiswa')->insert([
                              'iterasi' => $step,
                              'mahasiswa_id' => $mhs->id,
                              'c1' => $c1,
                              'c2' => $c2,
                              'c3' => $c3,
                              'c4' => $c4,
                              'cluster' => $cluster,
                            ]);
                         
                            if($cluster == 'C1'){
                           
                              $hasil_cluster = DB::table('hasil_centroid_beasiswa')->updateOrInsert(
                                [
                                  'iterasi' => $step,
                                  'c1a' => $mhs->jenjang_pendidikan,
                                  'c1b' => $mhs->ipk,
                                  'c1c' => $mhs->aktif_organisasi,
                                  'c1d' => $mhs->semester,
                                  'c1e' => $mhs->sedang_menerima_beasiswa,
                                  'c1f' => $mhs->domisili,
                                  'c1g' => $mhs->tunggakan,
                                
                                  'mahasiswa_id' => $mhs->id
                                ],
                                [
                                'c1a' => $mhs->jenjang_pendidikan,
                                'c1b' => $mhs->ipk,
                                'c1c' => $mhs->aktif_organisasi,
                                'c1d' => $mhs->semester,
                                'c1e' => $mhs->sedang_menerima_beasiswa,
                                'c1f' => $mhs->domisili,
                                'c1g' => $mhs->tunggakan,
                                'iterasi' => $step,
                                'mahasiswa_id' => $mhs->id
                                ]
                              );
                            } elseif($cluster == 'C2'){
                              $hasil_cluster = DB::table('hasil_centroid_beasiswa')->updateOrInsert(
                                [
                                  'iterasi' => $step,
                                    'c2a' => $mhs->jenjang_pendidikan,
                                    'c2b' => $mhs->ipk,
                                    'c2c' => $mhs->aktif_organisasi,
                                    'c2d' => $mhs->semester,
                                    'c2e' => $mhs->sedang_menerima_beasiswa,
                                    'c2f' => $mhs->domisili,
                                    'c2g' => $mhs->tunggakan,
                                  'mahasiswa_id' => $mhs->id
                                ],
                                [ 'c2a' => $mhs->jenjang_pendidikan,
                                    'c2b' => $mhs->ipk,
                                    'c2c' => $mhs->aktif_organisasi,
                                    'c2d' => $mhs->semester,
                                    'c2e' => $mhs->sedang_menerima_beasiswa,
                                    'c2f' => $mhs->domisili,
                                    'c2g' => $mhs->tunggakan,
                                'iterasi' => $step,
                                'mahasiswa_id' => $mhs->id
                                ]
                              );
                            } elseif($cluster == 'C3'){
                              $hasil_cluster = DB::table('hasil_centroid_beasiswa')->updateOrInsert(
                                [
                                  'iterasi' => $step,
                                    'c3a' => $mhs->jenjang_pendidikan,
                                    'c3b' => $mhs->ipk,
                                    'c3c' => $mhs->aktif_organisasi,
                                    'c3d' => $mhs->semester,
                                    'c3e' => $mhs->sedang_menerima_beasiswa,
                                    'c3f' => $mhs->domisili,
                                    'c3g' => $mhs->tunggakan,
                                  'mahasiswa_id' => $mhs->id
                                ],
                                ['c3a' => $mhs->jenjang_pendidikan,
                                    'c3b' => $mhs->ipk,
                                    'c3c' => $mhs->aktif_organisasi,
                                    'c3d' => $mhs->semester,
                                    'c3e' => $mhs->sedang_menerima_beasiswa,
                                    'c3f' => $mhs->domisili,
                                    'c3g' => $mhs->tunggakan,
                                'iterasi' => $step,
                                'mahasiswa_id' => $mhs->id
                                ]
                              );
                            } elseif ($cluster == 'C4'){
                              $hasil_cluster = DB::table('hasil_centroid_beasiswa')->updateOrInsert(
                                [
                                  'iterasi' => $step,
                                    'c4a' => $mhs->jenjang_pendidikan,
                                    'c4b' => $mhs->ipk,
                                    'c4c' => $mhs->aktif_organisasi,
                                    'c4d' => $mhs->semester,
                                    'c4e' => $mhs->sedang_menerima_beasiswa,
                                    'c4f' => $mhs->domisili,
                                    'c4g' => $mhs->tunggakan,
                                  'mahasiswa_id' => $mhs->id
                                ],
                                ['c4a' => $mhs->jenjang_pendidikan,
                                    'c4b' => $mhs->ipk,
                                    'c4c' => $mhs->aktif_organisasi,
                                    'c4d' => $mhs->semester,
                                    'c4e' => $mhs->sedang_menerima_beasiswa,
                                    'c4f' => $mhs->domisili,
                                    'c4g' => $mhs->tunggakan,
                                'iterasi' => $step,
                                'mahasiswa_id' => $mhs->id
                                ]
                              );
                            }
                          ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="9" class="text-center">Data Kosong</td>    
                            </tr>
                        <?php endif; ?>
                          <?php 
                           $stop = false;
                            if($step >1) {
                              $hasil_sebelumnya = DB::table('hasil_iterasi_beasiswa')->where('iterasi', $step - 1)->get();
                                        $hasil_sekarang = DB::table('hasil_iterasi_beasiswa')->where('iterasi', $step)->get();
                                        // loop untuk membandingkan hasil iterasi sebelumnya dengan hasil iterasi sekarang
                                        foreach($hasil_sebelumnya as $key => $value) {
                                            if($value->c1 != $hasil_sekarang[$key]->c1 || $value->c2 != $hasil_sekarang[$key]->c2 || $value->c3 != $hasil_sekarang[$key]->c3 || $value->c4 != $hasil_sekarang[$key]->c4) {
                                                $stop = false;
                                                break;
                                            } else {
                                                $stop = true;
                                            }
                                        }
                            }
                          ?>
                          <?php if($stop): ?>
                            <tr>
                              <td colspan="9" class="text-center">
                                <div class="alert alert-success">
                                  <h4 class="alert-heading">Proses Selesai!</h4>
                                  <p class="mb-0">
                                    <strong>Perhatian!</strong> Proses k-means telah selesai dilakukan.
                                  </p>
                                </div>
                              </td>    
                            </tr>
                            
                            <tr>
                              <td colspan="9" class="text-center">
                                <a href="<?php echo e(route('kmeans.beasiswa', ['step' => 0])); ?>" class="btn btn-primary">Kembali ke Awal</a>
                              </td>
                            </tr>
                          
                          <?php else: ?>
                          
                          <?php if($step > 1): ?>
                          <tr>
                            <td colspan="4" class="text-center">
                              <a href="<?php echo e(route('kmeans.beasiswa', ['step' => $step - 1])); ?>" class="btn btn-primary">Kembali</a>
                            </td>
                              
                            <?php endif; ?>
                            <td colspan="5" class="text-center">
                              <a href="<?php echo e(route('kmeans.beasiswa', ['step' => $step + 1])); ?>" class="btn btn-primary">Lanjutkan Proses</a>
                             </td>    
                          </tr>
                            
                          <?php endif; ?>
                      </tbody>
                    </table>
                  </div>
                </div>
            </div>
        </div>

    </div>
    <?php if($stop): ?>
    <div class="col-md-12">
      <div class="white-box">
          <h3 class="box-title">Mahasiswa</h3>
          <div class="widget-content searchable-container list">
              <div class="card card-body">
                <div class="alert alert-info">
                  <h4 class="alert-heading">Informasi!</h4>
                  <p class="mb-0">
                    <strong>Perhatian!</strong> Berikut adalah hasil cluster dari proses k-means.
                  </p>
                </div>
              
                <div class="table-responsive">
                  <table class="table search-table v-middle">
                    <thead class="header-item">
                    
                      <th class="font-weight-medium fs-4">Nama</th>
                     <th class="font-weight-medium fs-4">Jenjang Pendidikan</th>
                        <th class="font-weight-medium fs-4">IPK</th>
                        <th class="font-weight-medium fs-4">Aktif Organisasi</th>
                        <th class="font-weight-medium fs-4">Semester</th>
                        <th class="font-weight-medium fs-4">Sedang Menerima Beasiswa</th>
                        <th class="font-weight-medium fs-4">Domisili</th>
                        <th class="font-weight-medium fs-4">Tunggakan</th>
                        <th class="font-weight-medium fs-4">Cluster</th>
                    </thead>
                    <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                      <!-- row -->
                      <tr class="search-items">
                        <td>
                          <div class="d-flex align-items-center">
                            <img
                               src="<?php echo e(asset('assets/images/profile/user-1.jpg')); ?>"
                               class="rounded  round-50"
                               />
                            <div class="ms-3">
                               <h6 class=" mb-0">
                                  <?php echo e($mhs->nama); ?>

                               </h6>
                               <span class="text-muted"
                                  ><?php echo e($mhs->jurusan); ?>

                                  </span
                                  >
                               <br />
                            </div>
                         </div>
                        </td>
             
                         <?php 
                          $hasil_iterasi = DB::table('hasil_iterasi_beasiswa')->where('mahasiswa_id', $mhs->id)->where('iterasi', $step)->first();
                          $c1 = $hasil_iterasi->c1;
                          $c2 = $hasil_iterasi->c2;
                          $c3 = $hasil_iterasi->c3;
                          $c4 = $hasil_iterasi->c4;
                          $cluster = $hasil_iterasi->cluster;
                          ?>
                            <td>
                                <?php echo e($mhs->jenjang_pendidikan_text); ?>

                            </td>
                            <td>
                                <?php echo e($mhs->ipk_text); ?>

                            </td>
                            <td>
                                <?php echo e($mhs->aktif_organisasi_text); ?>

                            </td>
                            <td>
                                <?php echo e($mhs->semester_text); ?>

                            </td>
                            <td>
                                <?php echo e($mhs->sedang_menerima_beasiswa_text); ?>

                            </td>
                            <td>
                                <?php echo e($mhs->domisili_text); ?>

                            </td>
                            <td>
                                <?php echo e($mhs->tunggakan_text); ?>

                            </td>


                          <td>
                              <?php if($cluster == 'C1'): ?>
                                <?php 
                                //  update cluster
                                 $update_cluster = DB::table('mahasiswa')->where('id', $mhs->id)->update(
                                    ['klaster_beasiswa' => 'C1']
                                );
                                ?>
                                <span class="badge bg-success">C1</span>
                              <?php elseif($cluster == 'C2'): ?>
                                <span class="badge bg-warning">C2</span>
                                <?php 
                                 $update_cluster = DB::table('mahasiswa')->where('id', $mhs->id)->update(['klaster_beasiswa' => 'C2']);
                                ?>
                              <?php elseif($cluster == 'C3'): ?>
                                <span class="badge bg-danger">C3</span>
                                <?php 
                                //  update cluster
                                 $update_cluster = DB::table('mahasiswa')->where('id', $mhs->id)->update(['klaster_beasiswa' => 'C3']);
                                ?>
                                <?php elseif($cluster == 'C4'): ?>
                                <span class="badge bg-info">C4</span>
                                <?php
                                //  update cluster
                                 $update_cluster = DB::table('mahasiswa')->where('id', $mhs->id)->update(['klaster_beasiswa' => 'C4']);
                                ?>

                              <?php endif; ?>
                          </td>

                          </td>
                        </tr>
                        <!-- /.row -->
                    
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <tr>
                              <td colspan="9" class="text-center">Data Kosong</td>    
                          </tr>
                      <?php endif; ?>
                      
                    </tbody>
                  </table>
                </div>
              </div>
          </div>
      </div>
  </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kampus\Tugas\Algoritma-Kmeans-Menentukan-Penerima-Beasiswa\resources\views/kmeans/beasiswa.blade.php ENDPATH**/ ?>