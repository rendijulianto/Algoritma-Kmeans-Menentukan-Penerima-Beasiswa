<?php $__env->startSection('breadcrumb'); ?>
<div class="font-weight-medium shadow-none position-relative overflow-hidden mb-4">
  <div class="d-sm-flex d-block justify-content-between align-items-center">
     <h5 class="mb-0 fw-semibold text-uppercase"> 
        Kelola Mahasiswa
     </h5>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-md-12">
     <div class="card">
        <div class="card-body">
           <h5 class="card-title mb-0">Mahasiswa</h5>
           <a  class="btn btn-primary float-end" href="<?php echo e(route('mahasiswa.create')); ?>">
               <iconify-icon icon="akar-icons:plus" class="iconify-md"></iconify-icon>
            Tambah Mahasiswa
           </a>
        </div>
        <div class="table-responsive">
           <table class="table no-wrap user-table mb-0">
              <thead>
                 <tr>
                    <th
                       scope="col"
                       class="border-0  ps-4"
                       >
                       #
                    </th>
                    <th scope="col" class="border-0 ">
                        Nama
                    </th>
                    <th scope="col" class="border-0 ">
                       Pekerjaan Ayah
                    </th>
                    <th scope="col" class="border-0 ">
                        Pekerjaan Ibu
                    </th>
                    
                    <th scope="col" class="border-0 ">
                        Jumlah Saudara
                    </th>
                    <th scope="col" class="border-0 ">
                        Kondisi Anak
                    </th>
                    <th scope="col" class="border-0 ">
                       Manage
                    </th>
                 </tr>
              </thead>
              <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td class="ps-4"><?php echo e($mhs->id); ?></td>
                  <td>
                     <div class="d-flex align-items-center">
                        <img
                           src="<?php echo e(asset('assets/images/profile/user-1.jpg')); ?>"
                           class="rounded  round-50"
                           />
                        <div class="ms-3">
                           <h6 class=" mb-0">
                              <?php echo e($mhs->nama); ?>

                           </h6>
                           <span class="text-muted"
                              ><?php echo e($mhs->jurusan); ?>

                              </span
                              >
                           <br />
                           <?php if($mhs->status_penerima_beasiswa == 1): ?>
                              <span class="badge bg-success">Menerima Beasiswa </span> 
                           <?php else: ?>
                              <span class="badge bg-danger">Tidak Menerima Beasiswa </span>
                           <?php endif; ?>
                        </div>
                     </div>
                  </td>
                  <td>
                     <span>
                        <?php echo e($mhs->pekerjaan_ayah_text); ?>

                     </span> <br />
                     <span>
                        <?php echo e($mhs->penghasilan_ayah_text); ?>

                      </span>
                  </td>
                  <td>
                      <span>
                          <?php echo e($mhs->pekerjaan_ibu_text); ?>

                      </span> <br />
                      <span>
                          <?php echo e($mhs->penghasilan_ibu_text); ?>

                      </span>
                  </td>
         
                
                  <td>
                      <span>
                          <?php echo e($mhs->jumlah_saudara_text); ?>

                      </span>
                  </td>
                  <td>
                      <span>
                          <?php echo e($mhs->kondisi_anak_text); ?>

                      </span>
                  </td>
                  <td>
                  
                     <a href="<?php echo e(route('mahasiswa.edit', $mhs->id)); ?>" class="text-dark edit">
                        <iconify-icon icon="solar:pen-bold" class="iconify-md"></iconify-icon>
                     </a>
                     <form action="<?php echo e(route('mahasiswa.destroy', $mhs->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Yakin ingin menghapus data ini?')">
                       
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-link text-danger" type="submit">
                           <iconify-icon icon="solar:trash-bin-2-bold" class="iconify-md"></iconify-icon>
                        </button>
                      </form>
                      <a href="<?php echo e(route('mahasiswa.show', $mhs->id)); ?>" class="text-dark edit">
                        <iconify-icon icon="solar:eye-bold" class="iconify-md"></iconify-icon>
                     </a>
                  </td>
                  </td>
               </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> 
                <tr>
                    <td colspan="9" class="text-center">Data Kosong</td>
                </tr>
                <?php endif; ?>
        
              </tbody>
           </table>
          </div>
        </div>
        <?php echo e($mahasiswa->withQueryString()->links('pagination::bootstrap-4')); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kampus\Tugas\Algoritma-Kmeans-Menentukan-Penerima-Beasiswa\resources\views/mahasiswa/index.blade.php ENDPATH**/ ?>